# UZ SMETA AI
Telegram bot for rough construction quantity and cost calculations.

## Deploy on Render
- Create a Render Blueprint from this GitHub repo and use `render.yaml`.
- In Render Environment settings, add `TELEGRAM_BOT_TOKEN` securely. Do not commit secrets.
- Deploy, check logs, then send `/start` to your Telegram bot.

## Features
- Brick wall volume and approximate count (rough 400 bricks/m³ assumption; verify size/joints)
- Concrete volume and 5% allowance
- Area calculation
- Plaster material estimate using entered consumption rate
- Manual estimate items and total

Calculations are approximate and must be checked against project drawings, specifications, current prices and applicable standards. This bot does not parse DWG/PDF drawings or fetch live prices.
