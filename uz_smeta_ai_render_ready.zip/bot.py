import os, logging
from decimal import Decimal, InvalidOperation
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, ConversationHandler, ContextTypes, filters
logging.basicConfig(level=logging.INFO)
TOKEN=os.getenv('TELEGRAM_BOT_TOKEN')
MENU=[["🧱 G'isht hisoblash","🏗 Beton hisoblash"],["📐 Maydon","🪣 Suvoq hisoblash"],["💰 Smeta tuzish","❌ Bekor qilish"]]
KB=ReplyKeyboardMarkup(MENU,resize_keyboard=True)
STATES=range(13)
def n(s):
 try:return Decimal(s.strip().replace(',','.'))
 except (InvalidOperation,AttributeError):raise ValueError('Raqam kiriting (masalan 3.5).')
async def start(u,c):
 c.user_data.clear();await u.message.reply_text("Assalomu alaykum! UZ SMETA AI — qurilish hisob-kitob yordamchisi. Menyudan bo'lim tanlang.",reply_markup=KB);return ConversationHandler.END
async def helpcmd(u,c):await u.message.reply_text("Menyudan hisob turini tanlang. /cancel — bekor qilish, smeta uchun /done — yakunlash.",reply_markup=KB)
async def cancel(u,c):c.user_data.clear();await u.message.reply_text('Bekor qilindi.',reply_markup=KB);return ConversationHandler.END
async def route(u,c):
 t=u.message.text
 if t=="🧱 G'isht hisoblash": c.user_data['kind']='brick';await u.message.reply_text('Devor uzunligi (m) kiriting:');return 0
 if t=='🏗 Beton hisoblash':c.user_data['kind']='concrete';await u.message.reply_text('Beton uzunligi (m):');return 3
 if t=='📐 Maydon':c.user_data['kind']='area';await u.message.reply_text('Uzunlik (m):');return 6
 if t=='🪣 Suvoq hisoblash':c.user_data['kind']='plaster';await u.message.reply_text('Suvaladigan maydon (m²):');return 8
 if t=='💰 Smeta tuzish':c.user_data['items']=[];await u.message.reply_text('Smeta bandi nomini yozing:');return 11
 await u.message.reply_text('Menyudan tanlang yoki /help yuboring.',reply_markup=KB);return ConversationHandler.END
async def brick_l(u,c):
 try:c.user_data['l']=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 0
 await u.message.reply_text('Devor balandligi (m):');return 1
async def brick_h(u,c):
 try:c.user_data['h']=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 1
 await u.message.reply_text('Devor qalinligi (m), masalan 0.25:');return 2
async def brick_t(u,c):
 try:t=n(u.message.text);v=c.user_data['l']*c.user_data['h']*t
 except ValueError as e:await u.message.reply_text(str(e));return 2
 await u.message.reply_text(f"Devor hajmi: {v:.3f} m³\nG'isht taxminan: {v*400:.0f} dona (400 dona/m³ taxminiy koeffitsiyent). G'isht o'lchami va chokni tekshiring.",reply_markup=KB);return ConversationHandler.END
async def concrete_l(u,c):
 try:c.user_data['l']=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 3
 await u.message.reply_text('Eni (m):');return 4
async def concrete_w(u,c):
 try:c.user_data['w']=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 4
 await u.message.reply_text('Qalinlik/balandlik (m):');return 5
async def concrete_d(u,c):
 try:v=c.user_data['l']*c.user_data['w']*n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 5
 await u.message.reply_text(f'Beton hajmi: {v:.3f} m³\n5% zaxira bilan: {v*Decimal("1.05"):.3f} m³',reply_markup=KB);return ConversationHandler.END
async def area_l(u,c):
 try:c.user_data['l']=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 6
 await u.message.reply_text('Eni (m):');return 7
async def area_w(u,c):
 try:a=c.user_data['l']*n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 7
 await u.message.reply_text(f'Maydon: {a:.2f} m²',reply_markup=KB);return ConversationHandler.END
async def plaster_area(u,c):
 try:c.user_data['a']=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 8
 await u.message.reply_text('Suvoq qalinligi (mm):');return 9
async def plaster_thick(u,c):
 try:c.user_data['t']=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 9
 await u.message.reply_text('Ishlab chiqaruvchi sarfi (kg/m²/mm) ni kiriting, qadoqdagi normadan:');return 10
async def plaster_cons(u,c):
 try:kg=c.user_data['a']*c.user_data['t']*n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 10
 await u.message.reply_text(f'Taxminiy suvoq material: {kg:.1f} kg. Sarf normasi qadoqdan tekshirilsin.',reply_markup=KB);return ConversationHandler.END
async def smeta_name(u,c):c.user_data['name']=u.message.text.strip();await u.message.reply_text('Shu bandning jami narxini soʻmda kiriting (miqdor × birlik narxi):');return 12
async def smeta_price(u,c):
 try:p=n(u.message.text)
 except ValueError as e:await u.message.reply_text(str(e));return 12
 c.user_data['items'].append((c.user_data['name'],p));total=sum((x[1] for x in c.user_data['items']),Decimal(0));await u.message.reply_text(f"Qo'shildi: {c.user_data['name']} — {p:,.0f} so'm. Jami: {total:,.0f} so'm.\nYana band nomini yozing yoki /done bosing.");return 11
async def done(u,c):
 items=c.user_data.get('items',[]);total=sum((x[1] for x in items),Decimal(0));msg='SMETA\n'+'\n'.join(f'• {name}: {price:,.0f} soʻm' for name,price in items)+f'\n\nJAMI: {total:,.0f} soʻm';await u.message.reply_text(msg,reply_markup=KB);c.user_data.clear();return ConversationHandler.END
async def main():
 if not TOKEN:raise RuntimeError('TELEGRAM_BOT_TOKEN environment variable is missing')
 app=Application.builder().token(TOKEN).build()
 conv=ConversationHandler(entry_points=[MessageHandler(filters.Regex("^(🧱 G'isht hisoblash|🏗 Beton hisoblash|📐 Maydon|🪣 Suvoq hisoblash|💰 Smeta tuzish)$"),route)],states={0:[MessageHandler(filters.TEXT&~filters.COMMAND,brick_l)],1:[MessageHandler(filters.TEXT&~filters.COMMAND,brick_h)],2:[MessageHandler(filters.TEXT&~filters.COMMAND,brick_t)],3:[MessageHandler(filters.TEXT&~filters.COMMAND,concrete_l)],4:[MessageHandler(filters.TEXT&~filters.COMMAND,concrete_w)],5:[MessageHandler(filters.TEXT&~filters.COMMAND,concrete_d)],6:[MessageHandler(filters.TEXT&~filters.COMMAND,area_l)],7:[MessageHandler(filters.TEXT&~filters.COMMAND,area_w)],8:[MessageHandler(filters.TEXT&~filters.COMMAND,plaster_area)],9:[MessageHandler(filters.TEXT&~filters.COMMAND,plaster_thick)],10:[MessageHandler(filters.TEXT&~filters.COMMAND,plaster_cons)],11:[MessageHandler(filters.TEXT&~filters.COMMAND,smeta_name)],12:[MessageHandler(filters.TEXT&~filters.COMMAND,smeta_price)]},fallbacks=[CommandHandler('cancel',cancel),CommandHandler('done',done),MessageHandler(filters.Regex('^❌ Bekor qilish$'),cancel)],allow_reentry=True)
 app.add_handler(CommandHandler('start',start));app.add_handler(CommandHandler('help',helpcmd));app.add_handler(conv);app.add_handler(MessageHandler(filters.Regex('^❌ Bekor qilish$'),cancel));app.run_polling(drop_pending_updates=True)
if __name__=='__main__':import asyncio;asyncio.run(main())
